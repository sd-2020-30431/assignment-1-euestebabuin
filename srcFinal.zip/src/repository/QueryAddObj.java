package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class QueryAddObj {

	private Connection dbc;
	private PreparedStatement st;
	
	public void update(String query) {
		System.out.println(query);
		databaseOp(query);
		closeStuff();
	}
	
	private void databaseOp(String que) {
		dbc = ConnectR.getConnection();
		st = null;
		
		try
		{
			st = dbc.prepareStatement(que);
			st.executeUpdate();
		} catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Database Connection Error");
		}
	}
	
	private void closeStuff()
	{
		ConnectR.close(st);
		ConnectR.close(dbc);
	}
}
