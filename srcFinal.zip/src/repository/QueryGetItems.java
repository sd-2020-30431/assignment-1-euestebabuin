package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QueryGetItems {

	private ResultSet rs;
	private Connection dbc;
	private PreparedStatement st;

	
	public Object[][] getItems(String query){
		databaseOp(query);
		Object data[][] = parseResultSet();
		closeStuff();
		return data;
	}
	
	private Object[][] parseResultSet(){
		Object data[][] = null;
		int size = 0, i = 0;
		try {
			while(rs.next())
				size++;
			data =  new Object[size][6];
			rs.absolute(0);
			while(i<size) {
				rs.next();
				data[i][0] = rs.getString("name");
				data[i][1] = rs.getInt("quantity");
				data[i][2] = rs.getInt("kcal");
				data[i][3] = rs.getString("buydate");
				data[i][4] = rs.getString("expdate");
				data[i][5] = rs.getInt("id");
					i++;
			}
		}
		catch(SQLException e) {
			System.out.println("SQL Exception");
			e.printStackTrace();
		}
		return data;
	}
	
	private void databaseOp(String que) {
		dbc = ConnectR.getConnection();
		st = null;
		rs = null;
		
		try
		{
			st = dbc.prepareStatement(que);
			rs = st.executeQuery();
		} catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Database Connection Error");
		}
	}
	
	private void closeStuff()
	{
		ConnectR.close(rs);
		ConnectR.close(st);
		ConnectR.close(dbc);
	}
}
