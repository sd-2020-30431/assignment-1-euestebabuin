package model;

import java.util.Date;

public class GroceryItem {
	private String name;
	private int quantity;
	private int kcal;
	private Date buyDate;
	private Date expDate;
	private Date consDate;
	
	public GroceryItem(String n, int q, int k, Date bd, Date eD, Date cD) {
		name = n; quantity = q; kcal = k;
		buyDate = bd; expDate = eD; consDate = cD;
	}
	
	public int getCaloricValue() {
		return quantity * kcal;
	}
}
