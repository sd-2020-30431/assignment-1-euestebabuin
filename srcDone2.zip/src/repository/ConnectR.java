package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

public class ConnectR {
	private static final String user = "root";
	private static final String pass = "";
	private static final String url = "jdbc:mysql://localhost:3306/foodwaste?useSSL=false";
	private static final String driver = "com.mysql.jdbc.Driver";
	
	private static  ConnectR instance = new ConnectR();
	
	Connection conn;
	
	public ConnectR()
	{
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			System.out.println("Driver error");
			return;
		}
	}

	private Connection createConnection()
	{
		conn = null;
		try
		{
			conn = DriverManager.getConnection(url, user, pass);
		}
		catch(Exception e)
		{
			System.out.println("Connection error");
		}
		return conn;
	}
	
	public static Connection getConnection()
	{
		return instance.createConnection();
	}
	
	public static void close(Connection c)
	{
		if(c != null)
			try {
				c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	public static void close(PreparedStatement c)
	{
		if(c != null)
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public static void close(ResultSet c)
	{
		if(c != null)
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
