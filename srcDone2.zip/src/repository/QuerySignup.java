package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class QuerySignup {
	
	String username;
	String password;
	public QuerySignup(String user, String pass){
		password = pass;
		username = user;
	}
	
	public boolean unique() throws Exception{
		Connection dbc = ConnectR.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		st = dbc.prepareStatement("Select * from client where user = '" + username + "';");
		rs = st.executeQuery();
		boolean rez = !rs.next();
		

		ConnectR.close(dbc);
		ConnectR.close(st);
		ConnectR.close(rs);
		
		return rez;
	}
	
	public boolean register() throws Exception {
		Connection dbc = ConnectR.getConnection();
		PreparedStatement st = null;
		
		if(username.length() < 5 || password.length() < 8) {
			ConnectR.close(dbc);
			return false;
		}
		else {
			st = dbc.prepareStatement("Insert into client (user,pass) values ('" + 
			username + "','" + password + "');");
			st.executeUpdate();
			ConnectR.close(dbc);
			return true;
		}
	}
}
