package business;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

import gui.MainGUI;
import repository.QueryAddObj;
import repository.QueryGetItems;

public class MainBusiness {
	private MainGUI mgui;
	private QueryAddObj qaobj;
	private QueryGetItems qgitms;
	private Valid valid;
	private Object data[][];
	private int clientId;	

	private static final long toDays = 1000 * 3600 * 24;
	
	public MainBusiness(MainGUI _mgui, QueryAddObj _qaobj, QueryGetItems _qgitms, int id, Valid _valid) {
		mgui = _mgui;
		qaobj = _qaobj;
		qgitms = _qgitms;
		clientId = id;
		valid = _valid;
		mgui.feedMB(this);
		this.getTableData();
		this.checkBurnDown(true);
	}
	
	public void getTableData() {
		String query = "Select * from groceries where id_client = " + clientId + ";";
		data = qgitms.getItems(query);
		mgui.refreshTable(data);
	}
	
	public void deleteItem(int rowIndex) {
		if(rowIndex != -1) {
			String query = "Delete from groceries where id = " + data[rowIndex][5] + ";";
			qaobj.update(query);
		}
		getTableData();
	}
	
	public void insert(String newobj[]) {
		if(valid.validateData(newobj)) {
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			Date date = new Date(); //today buy date by default
			String query = "Insert into groceries (id_client, name, quantity, kcal, buydate, expdate) values (" +
			clientId + ",'" + newobj[0] + "'," + newobj[1] + "," + newobj[2] + ",'" + dateFormat.format(date)+"','" + newobj[3] + "');";
			System.out.println(query);
			qaobj.update(query);
		}
		getTableData();
	}
	public void showReport(int days) {
		System.out.println(data[1][0]);
		@SuppressWarnings("rawtypes")
		AbstractFactoryRep afr = AbstractFactoryProvider.getFactory(days);
		if(days == 7) {
			WeeklyReport wr = (WeeklyReport) afr.create(data);
			mgui.refreshTable(wr.getData());
		}
		
		if(days == 31) {
			MonthlyReport mr = (MonthlyReport) afr.create(data);
			mgui.refreshTable(mr.getData());
		}
	}
	
	public void checkBurnDown(boolean show) {
		int today_bdr = 0;
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		for(int i = 0; i < data.length; i++) {
			long todaymil = new Date().getTime();
			long productmil = 0;
			try {productmil = dateFormat.parse((String)data[i][4]).getTime();}
			catch(Exception e) {e.printStackTrace();}
			float days_to_expire = ((productmil - todaymil)/(1.0f * toDays));
			if(days_to_expire > 0) {
				today_bdr += (int)data[i][1] * (int)data[i][2] / days_to_expire;
			}
			
		}
		if(today_bdr > 2000) {
			if(show)
			JOptionPane.showMessageDialog(null, "Warning, today's ideal burning rate is too high " + today_bdr,
					"Imminent Waste!", JOptionPane.WARNING_MESSAGE);
			mgui.colorDonate('r');
		}
		else {
			if(show)
			JOptionPane.showMessageDialog(null, "Today's ideal burning rate: " + today_bdr, "Welcome!",
					JOptionPane.INFORMATION_MESSAGE);
			mgui.colorDonate('a');
		}
	}
}
