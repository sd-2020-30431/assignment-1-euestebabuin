package business;

public interface AbstractFactoryRep<T> {
	T create(Object[][] data);
}
