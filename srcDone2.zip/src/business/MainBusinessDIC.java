package business;

import gui.MainGUI;
import repository.QueryAddObj;
import repository.QueryGetItems;

public class MainBusinessDIC {
	int clientId;
	public MainBusinessDIC(int id) {
		clientId = id;
	}
	public MainBusiness createMainBusiness() {
		MainGUI mg = new MainGUI();
		QueryAddObj qaobj = new QueryAddObj();
		QueryGetItems qgitms = new QueryGetItems();
		Valid valid = new Valid();
		MainBusiness mb = new MainBusiness(mg, qaobj, qgitms, clientId, valid);
		return mb;
	}
}
