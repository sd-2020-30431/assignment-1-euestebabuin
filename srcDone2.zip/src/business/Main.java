package business;


public class Main {
	private int clientId;
	public Main(int _clientId) {
		clientId = _clientId;
	}
	
	public void startService() {
		MainBusinessDIC mbdic = new MainBusinessDIC(clientId);
		MainBusiness mb = mbdic.createMainBusiness();
	}
}
