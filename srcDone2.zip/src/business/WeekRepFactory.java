package business;

public class WeekRepFactory implements AbstractFactoryRep<WeeklyReport>{
	public WeeklyReport create (Object[][] data) {
		return new WeeklyReport(data);
	}
}
