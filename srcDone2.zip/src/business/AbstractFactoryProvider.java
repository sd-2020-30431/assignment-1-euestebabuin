package business;

public class AbstractFactoryProvider {
	@SuppressWarnings("rawtypes")
	public static AbstractFactoryRep getFactory(int days) {
		if(days == 7) {
			return new WeekRepFactory();
		}
		if(days == 31) {
			return new MonthlyRepFactory();
		}
		return null;
	}
}
