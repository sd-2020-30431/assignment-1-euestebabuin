package business;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

public class Valid {

	
	private boolean checkName(String s) {
		 return !s.isEmpty();
	}
	
	private boolean checkNr(String s) {
		try {
			int a = Integer.parseInt(s);
			if (a >= 0)
				return true;
		}
		catch(Exception e) {
			return false;
		}
		 return true;
	}
	private boolean checkDate(String s) {
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			dateFormat.parse(s);
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Date fromat dd-MM-yyyy", "Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		 return true;
	}
	
	public boolean validateData(String newobj[]) {
		
		if(checkName(newobj[0]) && checkNr(newobj[1]) &&
				checkNr(newobj[2]) && checkDate(newobj[3])) {
			return true;
		}
		else {
			JOptionPane.showMessageDialog(null, "Invalid data", "Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
}
