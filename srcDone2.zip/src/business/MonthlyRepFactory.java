package business;

public class MonthlyRepFactory implements AbstractFactoryRep<MonthlyReport>{

	@Override
	public MonthlyReport create(Object[][] data) {
		// TODO Auto-generated method stub
		return new MonthlyReport(data);
	}
	

}
