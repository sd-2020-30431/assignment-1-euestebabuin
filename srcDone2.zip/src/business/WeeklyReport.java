package business;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WeeklyReport {
	private Object[][] newData;
	private static final long toDays = 1000 * 3600 * 24;
	
	public WeeklyReport(Object[][] data) {
		createReport(data);
	}
	
	private void createReport(Object[][] data) {
		int nweek = 0; // last week's number of expired items
		newData = new Object[1][6];
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		for(int i = 0; i < data.length; i++) {
			long todaymil = new Date().getTime();
			long productmil = 0;
			try {productmil = dateFormat.parse((String)data[i][4]).getTime();}
			catch(Exception e) {e.printStackTrace();}
			int days_since_expired = (int)((todaymil - productmil)/toDays);
			if(days_since_expired > 0 && days_since_expired < 7) {
				nweek++;
			}
		}
		
		int k = 0;
		newData = new Object[nweek][6];
		for(int i = 0; i < data.length; i++) {
			long todaymil = new Date().getTime();
			long productmil = 0;
			try {productmil = dateFormat.parse((String)data[i][4]).getTime();}
			catch(Exception e) {e.printStackTrace();}
			int days_since_expired = (int)((todaymil - productmil)/toDays);
			if(days_since_expired > 0 && days_since_expired < 7) {
				newData[k++] = data[i].clone();
				newData[k-1][0] += " -Expired";
			}
		}
	}
	
	public Object[][] getData() {
		return newData;
	}
}
